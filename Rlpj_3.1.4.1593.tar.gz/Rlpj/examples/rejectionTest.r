
create 20 parameters


par = seq(1,2, len = 20)


# set up lpj on 2 cores (or more)

# run lpj with the different parameters and record the output, e.g. biomass

# plot the output as a function of the parameter 



