

#someParameterList = as.list(seq(x,x,len = 20))

# set up with less cores than parameter list
#clust<- setUpCluster(xxxx, type = "biomass")

#out <- clust$runParallel(someParameterList, type = "biomass")


#result <- rep(NA, lenth(someParameterList)

#for(i= 1:length(out)){

#}



