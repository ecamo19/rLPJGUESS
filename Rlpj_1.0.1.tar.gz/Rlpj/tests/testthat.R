
Sys.setenv("R_TESTS" = "")

library(Rlpj)
library(testthat)

test_check("Rlpj")
