typelist <- getTypeList()
typelist
