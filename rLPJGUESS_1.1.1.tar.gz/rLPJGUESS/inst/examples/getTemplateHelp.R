\dontrun{
# Get templates as r objects
template <- getTemplate("global")
template <- getTemplate("global_cf")
template <- getTemplate("global_cru")
template <- getTemplate("europe")
template <- getTemplate("europe_cf")
template <- getTemplate("europe_cru")


# Get templates written in a folder
getTemplate("global","/home/mainDir/")
getTemplate("global_cf","/home/mainDir/")
getTemplate("global_cru","/home/mainDir/")
getTemplate("europe","/home/mainDir/")
getTemplate("europe_cf","/home/mainDir/")
getTemplate("europe_cru", "/home/mainDir/")
)
}
